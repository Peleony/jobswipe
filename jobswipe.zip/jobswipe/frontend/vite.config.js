import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    proxy: {
      '/api': process.env.VITE_API_PROXY || 'http://127.0.0.1:8000',
      '/healthz': process.env.VITE_API_PROXY || 'http://127.0.0.1:8000',
    },
  },
  test: {
    environment: 'jsdom',
    restoreMocks: true,
  },
})
